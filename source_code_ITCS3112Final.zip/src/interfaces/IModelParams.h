#pragma once
#include <string>
class IModelParams {
public:
  virtual ~IModelParams() = default;
};
