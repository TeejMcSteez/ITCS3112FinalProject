#include "IModelParams.h"

class ICostCalculator {
  float Calculate(int numberOfTokens, IModelParams mdls);
};
